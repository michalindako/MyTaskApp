document.addEventListener('DOMContentLoaded', function() {
    const taskInput = document.getElementById('new-task');
    const taskTimeInput = document.getElementById('task-time');
    const addTaskButton = document.getElementById('add-task');
    const taskList = document.getElementById('task-list');
    const menuToggle = document.getElementById('menu-toggle');
    const drawer = document.getElementById('drawer');
    const themePicker = document.getElementById('theme-picker');
    const closeThemePicker = document.getElementById('close-theme-picker');
    const themeOptions = document.querySelectorAll('.theme-option');

    // Load saved theme
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        document.body.style.background = savedTheme;
    }

    // Toggle drawer
    menuToggle.addEventListener('click', function() {
        drawer.classList.toggle('open');
    });

    // Close drawer when clicking outside
    document.addEventListener('click', function(event) {
        if (!drawer.contains(event.target) && event.target !== menuToggle) {
            drawer.classList.remove('open');
        }
    });

    // Close drawer when an option is selected
    drawer.addEventListener('click', function(event) {
        if (event.target.tagName === 'A') {
            drawer.classList.remove('open');
        }
    });

    // Show theme picker
    document.getElementById('personalize-themes').addEventListener('click', function() {
        themePicker.style.display = 'block';
    });

    // Close theme picker
    closeThemePicker.addEventListener('click', function() {
        themePicker.style.display = 'none';
    });

    // Apply selected theme
    themeOptions.forEach(option => {
        option.addEventListener('click', function() {
            const color = option.getAttribute('data-color');
            document.body.style.background = color;
            localStorage.setItem('theme', color);
            themePicker.style.display = 'none';
        });
    });

    addTaskButton.addEventListener('click', function() {
        const taskText = taskInput.value.trim();
        const taskTime = taskTimeInput.value;
        if (taskText !== '' && taskTime !== '') {
            addTask(taskText, taskTime);
            taskInput.value = '';
            taskTimeInput.value = '';
        }
    });

    taskList.addEventListener('click', function(e) {
        if (e.target.classList.contains('edit-btn')) {
            const listItem = e.target.parentElement;
            editTask(listItem);
        } else if (e.target.classList.contains('delete-btn')) {
            const listItem = e.target.parentElement;
            taskList.removeChild(listItem);
        }
    });

    function addTask(taskText, taskTime) {
        const listItem = document.createElement('li');
        listItem.innerHTML = `
            <span class="task-text">${taskText}</span>
            <span class="task-time">${taskTime}</span>
            <button class="edit-btn"><i class="fas fa-pencil-alt"></i></button>
            <button class="delete-btn"><i class="fas fa-times"></i></button>
        `;
        taskList.appendChild(listItem);
    }

    function editTask(listItem) {
        const taskTextElement = listItem.querySelector('.task-text');
        const taskTimeElement = listItem.querySelector('.task-time');
        const newTaskText = prompt('Edit task', taskTextElement.textContent);
        const newTaskTime = prompt('Edit time', taskTimeElement.textContent);
        if (newTaskText !== null && newTaskTime !== null) {
            taskTextElement.textContent = newTaskText.trim();
            taskTimeElement.textContent = newTaskTime;
        }
    }

    // Navigation drawer options
    document.getElementById('today').addEventListener('click', function() {
        alert('Today\'s tasks feature coming soon!');
    });

    document.getElementById('tomorrow').addEventListener('click', function() {
        alert('Tomorrow\'s tasks feature coming soon!');
    });

    document.getElementById('someday').addEventListener('click', function() {
        alert('Someday\'s tasks feature coming soon!');
    });

    document.getElementById('completed-tasks').addEventListener('click', function() {
        alert('View Completed Tasks feature coming soon!');
    });
});
//notes option..edit this code

//document.addEventListener('DOMContentLoaded', function() {
    // Existing code

   // const noteList = document.getElementById('note-list');
  //  const addNoteButton = document.getElementById('add-note');

    // Add note button click event
    //addNoteButton.addEventListener('click', function() {
        //const noteText = prompt('Enter your note:');
        //if (noteText !== null && noteText.trim() !== '') {
            //addNoteToList(noteText.trim());
        //}
    //});

    // Function to add a note to the list
    //function addNoteToList(noteText) {
       // const listItem = document.createElement('li');
        //listItem.textContent = noteText;
       // noteList.appendChild(listItem);
  //  }

    // Navigation drawer options

    // Existing code
//});
//end of the code